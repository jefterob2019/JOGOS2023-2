using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 250;
    [SerializeField]
    private GameObject laserPrefab;
    [SerializeField]
    private Transform cannonPosition;
    public Transform localDisparoEsquerda;
    public Transform localDisparoDireita;
    public float tempoMaxPowerUp;
    public float tempoAtualPowerUp;
    public bool temPowerUp; 

    private SpriteRenderer sprite;
    private float time = 0;

    [SerializeField]
    private float shootRate = 0;
    [SerializeField]
    private float shootTotalTime;

    private Rigidbody2D rb2d;
    private float horizontal, vertical;

    [SerializeField]
    private GameObject prefabExplosion;

    // Start is called before the first frame update
    void Start()
    {
        temPowerUp = false; 
        sprite = GetComponent<SpriteRenderer>();
        rb2d = GetComponent<Rigidbody2D>();
        //sprite.color = Color.red;
        tempoAtualPowerUp = tempoMaxPowerUp;
    }

    // Update is called once per frame
    void Update()
    {
        horizontal = Input.GetAxis("Horizontal");
        vertical = Input.GetAxis("Vertical");
        Shoot();

        if(temPowerUp == true)
        {
            tempoAtualPowerUp -= Time.deltaTime;
            if(tempoAtualPowerUp <= 0)
            {
                DesativarPowerUp();
            }
        }        
    }

    public void FixedUpdate()
    {
        rb2d.velocity = new Vector2(horizontal * speed * Time.deltaTime, vertical * speed * Time.deltaTime);
    }

    void Shoot()
    {
        shootRate += Time.deltaTime;
        if (Input.GetMouseButton(0))
        {
            if(temPowerUp == false)
            {                    
                if (shootRate >= shootTotalTime)
             { 
                Instantiate(laserPrefab, cannonPosition.position, Quaternion.identity);
                shootRate = 0;
             }
        }
        else 
            {
                Instantiate(laserPrefab, cannonPosition.position, Quaternion.identity);
                Instantiate(laserPrefab, localDisparoDireita.position, localDisparoDireita.rotation);
                Instantiate(laserPrefab, localDisparoEsquerda.position, localDisparoEsquerda.rotation);
            }
        }
    }

    void DesativarPowerUp()
    {
        temPowerUp = false;
        tempoAtualPowerUp = tempoMaxPowerUp;
    }

    void Blink()
    {
        time += Time.deltaTime;
        if (time >= 0.1f)
        {
            time = 0;
            if (sprite.color == Color.white)
            {
                sprite.color = Color.red;
            }
            else
            {
                sprite.color = Color.white;
            }

        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        //Verificando colis�o com a nave
        if (other.CompareTag("Meteoro"))
        {
            Instantiate(prefabExplosion, transform.position, Quaternion.identity);
            Destroy(this.gameObject);
        }
    }}

