using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GeradorInimigos : MonoBehaviour
{
    [SerializeField]
    private GameObject[] prefabsInimigo;

    private const float xMax = 8.2f;
    private const float xMin = -8.2f;
    private const float y = 5.8f;

    void Start()
    {
        InvokeRepeating("InstanciarInimigos", 3.0f, 1f);
    }

    void InstanciarInimigos()
    {
        float novoX = Random.Range(xMin, xMax);
        float novoPU = Random.Range(xMin, xMax);

        float enemyBlackPercentage = Random.Range(1, 101);
        float powerUpPercentage = Random.Range(1, 101);

        Vector2 novaPosicao = new Vector2(novoX, y);
        if(enemyBlackPercentage >= 80)
        {
            Instantiate(prefabsInimigo[1], novaPosicao, Quaternion.identity);
        }
        else
        {
            Instantiate(prefabsInimigo[0], novaPosicao, Quaternion.identity);
        }
        Vector2 posicaoPowerUP = new Vector2(novoPU, y);
        if(powerUpPercentage >= 80)
        {
            Instantiate(prefabsInimigo[2], posicaoPowerUP, Quaternion.identity);
        }
    }
}
