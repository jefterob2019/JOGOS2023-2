using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBlack : MonoBehaviour
{
    [SerializeField]
    private float speed;

    private Rigidbody2D rb2d;
    private float shootRate = 0;

    [SerializeField]
    private float shootTotalTime;
    [SerializeField]
    private GameObject laserPrefab;

    private float newX = 0;
    private float xRandom = 0;
    private bool takeNewDirection = false;
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        Shoot();
    }

    void Shoot()
    {
        shootRate += Time.deltaTime;
        if (shootRate >= shootTotalTime)
        {
            Instantiate(laserPrefab, new Vector2(transform.position.x, transform.position.y - 0.5f), Quaternion.identity);
            shootRate = 0;
        }
    }

    private void FixedUpdate() //60fps
    {
        float newY = speed * Time.deltaTime;
        if (!takeNewDirection)
        {
            xRandom = Random.Range(-1, 2);
            takeNewDirection = true;
        }
        if (transform.position.y < 0)
        {
            
            newX = speed * Time.deltaTime;
        }
        else
        {
            newX = rb2d.velocity.x;
        }
        rb2d.velocity = new Vector2(xRandom * newX, newY);

    }

    private void OnBecameInvisible()
    {
        Destroy(this.gameObject);
    }
}
